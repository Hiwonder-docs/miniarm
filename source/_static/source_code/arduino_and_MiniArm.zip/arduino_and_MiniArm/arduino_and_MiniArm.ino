#include "MiniArm_ctl.h"

MiniArm_ctl mi_ctl;

void setup() {
  Serial.begin(115200);
  mi_ctl.serial_begin();
}

void loop() {
  //设置舵机角度
  Serial.println("set angles");
  uint8_t angles[5] = {73,10,161,57,90};
  //将PWM舵机的角度分别设置为73/10/161/57/90度，范围(0-180)
  mi_ctl.set_angles(angles); 
  delay(1500);

  //设置蜂鸣器
  Serial.println("set buzzer");
  //设置蜂鸣器的频率为532，运行时间为1000ms
  //两个参数的取值范围都是0-65535
  mi_ctl.set_buzzer(532,1000);
  delay(1500);

  //设置RGB灯
  Serial.println("set rgb");
  uint8_t rgb[3] = {0,255,0}; 
  //将RGB灯设置为绿色(范围0-255)
  mi_ctl.set_rgb(rgb);
  delay(1500);
  
  //读取并打印出当前状态的舵机角度
  Serial.println("read angles");
  uint8_t read_a[5] = {0,0,0,0,0};
  if(mi_ctl.read_angles(read_a))
  {
    Serial.print("angles: ");
    for(int i=0;i<5;i++){
      Serial.print(read_a[i]);
      Serial.print(" ");
    }
  }
  delay(100);

}
